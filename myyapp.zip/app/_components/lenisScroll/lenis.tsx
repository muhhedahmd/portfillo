"use client";

import ReactLenis, { LenisRef } from "lenis/react";

function SmoothScrolling({ children  , ref } : {
    children: React.ReactNode , 
    ref: React.ForwardedRef<LenisRef>
}) {
  return (
    <ReactLenis ref={ref} root options={{ lerp: 0.5, duration: 5, smoothWheel: true }}>
      {children}
    </ReactLenis>
  );
}

export default SmoothScrolling;