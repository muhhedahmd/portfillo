import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import React, { useRef } from 'react'
import GsapIcon from "@/public/icons/gsap.svg";
import FigmaIcon from "@/public/icons/icons8-figma.svg";
import GitIcon from "@/public/icons/icons8-git.svg";
import GitHubIcon from "@/public/icons/icons8-github-logo.svg";
import NextJsIcon from "@/public/icons/icons8-nextjs.svg";
import PrismaIcon from "@/public/icons/icons8-prisma-orm.svg";
import ReactIcon60 from "@/public/icons/icons8-react-60.svg";
import ReduxIcon from "@/public/icons/icons8-redux.svg";
import threeJs from "@/public/icons/Three.js.svg";
import SupabaseIcon from "@/public/icons/icons8-supabase.svg";
import Tailwind24 from "@/public/icons/icons8-tailwind-css-24.svg";
import shadcn from "@/public/icons/shadcn.svg";
import TypeScriptIcon from "@/public/icons/icons8-typescript.svg";
import Image from 'next/image';
import { cn } from '@/lib/utils';

const InfinityScroll = ({ isMobile }: { isMobile: boolean }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const skillsRef = useRef<HTMLDivElement>(null);
    const iconsRef = useRef<HTMLDivElement>(null);

    const svgComponents = [
        { Component: GsapIcon, name: 'Gsap' },
        { Component: FigmaIcon, name: 'Figma' },
        { Component: GitIcon, name: 'Git' },
        { Component: GitHubIcon, name: 'GitHub' },
        { Component: NextJsIcon, name: 'NextJs' },
        { Component: PrismaIcon, name: 'Prisma' },
        { Component: shadcn, name: 'shadcn' },
        { Component: threeJs, name: 'threeJs' },
        { Component: ReactIcon60, name: 'React' },
        { Component: ReduxIcon, name: 'Redux' },
        { Component: SupabaseIcon, name: 'Supabase' },
        { Component: Tailwind24, name: 'Tailwind' },
        { Component: TypeScriptIcon, name: 'TypeScript' },
    ];
    useGSAP(() => {
        if (isMobile) return;

        // Clone elements for seamless looping
        const skillsElements = skillsRef.current?.children || [];
        const iconsElements = iconsRef.current?.children || [];

        // Skills animation
        if (skillsRef.current && skillsElements.length > 0) {
            const skillsWidth = skillsElements[0].clientWidth * skillsElements.length;
            
            // Clone and append elements
            Array.from(skillsElements).forEach(el => {
                const clone = el.cloneNode(true);
                skillsRef.current?.appendChild(clone);
            });

            gsap.to(skillsRef.current, {
                x: -skillsWidth,
                duration: 20,
                ease: "none",
                repeat: -1,
                modifiers: {
                    x: gsap.utils.unitize(x => parseFloat(x) % skillsWidth)
                }
            });
        }

        // Icons animation
        if (iconsRef.current && iconsElements.length > 0) {
            const iconsWidth = iconsElements[0].clientWidth * iconsElements.length;
            
            // Clone and append elements
            Array.from(iconsElements).forEach(el => {
                const clone = el.cloneNode(true);
                iconsRef.current?.appendChild(clone);
            });

            gsap.to(iconsRef.current, {
                x: -iconsWidth,
                duration: 40,
                ease: "none",
                repeat: -1,
                modifiers: {
                    x: gsap.utils.unitize(x => parseFloat(x) % iconsWidth)
                }
            });
        }

    }, [isMobile]);

    return (
        <div ref={containerRef} className="w-full overflow-hidden bg-white ">
            {/* Skills Marquee */}
            <div className="relative overflow-hidden">
                <div 
                    ref={skillsRef}
                    className="flex w-max gap-4 whitespace-nowrap"
                >
                    {[...Array(20)].map((_, i) => (
                        <div 
                            key={`skill-${i}`} 
                            className="px-4 py-2"
                            style={{ minWidth: '100px' }}
                        >
                            <h3 className="text-2xl font-bold text-black">SKILLS</h3>
                        </div>
                    ))}
                </div>
            </div>

            {/* Icons Marquee */}
            <div className="relative overflow-hidden mt-1">
                <div 
                    ref={iconsRef}
                    className="flex w-max gap-8 whitespace-nowrap px-4 py-2"
                >
                    {[...svgComponents, ...svgComponents].map(({ Component, name }, i) => (
                        <div
                            key={`icon-${name}-${i}`}
                            className="flex items-center justify-center"
                            style={{ minWidth: '80px' }}
                        >
                            <Image
                                src={Component}
                                alt={name}
                                width={40}
                                height={40}
                                className={cn(
                                    'w-[2.5rem]  object-contain',
                                    name === "Gsap" && "w-[4rem]",
                                    // name === "shadcn" && "h-10"
                                )}
                            />
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default InfinityScroll;