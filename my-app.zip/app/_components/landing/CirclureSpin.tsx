"use client"
import useScrollSpeed from "@/hooks/useScrollSpeed"
import { cn } from "@/lib/utils"
import { useGSAP } from "@gsap/react"
import gsap from "gsap"
import { ArrowDownRightIcon } from "lucide-react"
import { useEffect, useState, useRef, type RefObject } from "react"

const CircularSpin = ({
  animState,
  headerRef,
  isMobile = false, 
}: {
  isMobile?: boolean
  headerRef: RefObject<HTMLDivElement | null>
  scrollProgress: number
  animState: "top" | "middle" | "bottom" | "top2"
}) => {
  const scrollSpeed = useScrollSpeed()
  const TEXT = "MOHAMED*AHAMED*"
  const [rotation, setRotation] = useState(0)
  const [currentSpeed, setCurrentSpeed] = useState(0)
  const animationRef = useRef<number | null>(null)
  const circleNameDivRef = useRef<HTMLDivElement>(null)
  // Base rotation speed (when idle)
  const baseSpeed = 0.2
  // Decay factor - how quickly speed returns to normal (higher = faster decay)
  const decayFactor = 0.95

  // Track if this is the initial render
  const [isFirstRender, setIsFirstRender] = useState(true)

  useEffect(() => {
    // Set first render to false after component mounts
    setIsFirstRender(false)
  }, [])

  useEffect(() => {
    // Update current speed based on scroll speed
    if (Math.abs(scrollSpeed) > 0.1) {
      // When actively scrolling, update the speed
      setCurrentSpeed(baseSpeed + Math.abs(scrollSpeed) * 0.3)
    }
  }, [scrollSpeed])

  useEffect(() => {
    // Animation function that continuously updates rotation
    const animate = () => {
      // Apply decay to gradually return to base speed when not scrolling
      setCurrentSpeed((prevSpeed) => {
        // If close enough to base speed, just return to base speed
        if (Math.abs(prevSpeed - baseSpeed) < 0.05) {
          return baseSpeed
        }
        // Otherwise, gradually decay toward base speed
        return baseSpeed + (prevSpeed - baseSpeed) * decayFactor
      })

      setRotation((prevRotation) => prevRotation + currentSpeed)

      animationRef.current = requestAnimationFrame(animate)
    }

    // Start the animation
    animationRef.current = requestAnimationFrame(animate)

    // Clean up animation on unmount
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [currentSpeed]) // Depend on currentSpeed to update the animation

  const [radius, setRadius] = useState(50)
  const [fontSpansSize, setfontSpansSize] = useState(1)

  const renderSpans = () => {
    const centerX = 0
    const centerY = 0
    return TEXT.split("").map((char, index) => {
      // Calculate the angle for this character
      const angle = (index / TEXT.length) * 2 * Math.PI

      // Position the character on the circle
      const x = centerX + radius * Math.cos(angle)
      const y = centerY + radius * Math.sin(angle)

      // Calculate the rotation angle in degrees
      // This is the key fix - rotate each letter to be tangent to the circle
      const rotation = angle * (180 / Math.PI) + 90 // +90 makes the letters face outward

      // Apply the transform
      const transform = `translate(${x}px, ${y}px) rotate(${rotation}deg)`

      return (
        <span
          style={{
            transform,
            fontSize: fontSpansSize + "rem",
          }}
          className="absolute text-accent z-20 p-1 text-sm font-semibold transition-all duration-500 ease-[cubic-bezier(0,0,0,1)]"
          key={index}
        >
          {char}
        </span>
      )
    })
  }

  const tl = useRef(gsap.timeline({ defaults: { ease: "power2.out" } }))
  const SpansDivRef = useRef<HTMLDivElement>(null)
  const arrowRef = useRef<SVGSVGElement>(null)
  const bgArrowRef = useRef<HTMLDivElement>(null)

  // Initial fade-in animation
  useEffect(() => {
    if (isFirstRender && circleNameDivRef.current && headerRef.current) {
      // Get the correct initial position
      const targetLeft = headerRef.current.getBoundingClientRect().right

      // Set initial position before fading in
      gsap.set(circleNameDivRef.current, {
        position: "fixed",
        zIndex: 100,
        top: 8,
        left: `calc(${targetLeft}px - 3.9rem)`,
        opacity: 0,
      })

      // Fade in smoothly
      gsap.to(circleNameDivRef.current, {
        opacity: 1,
        duration: 0.8,
        delay: 0.3,
        ease: "power2.inOut",
      })
    }
  }, [isFirstRender, headerRef])

  useGSAP(
    () => {
      if (!headerRef.current || isFirstRender) return

      // Get target positions
      const targetLeft = headerRef.current.getBoundingClientRect().right
      const targetTop = headerRef.current.getBoundingClientRect().top
        ? headerRef.current.getBoundingClientRect().top + 24 + 45
        : 0

      // Clear previous timeline
      if (tl.current) {
        tl.current.kill()
        tl.current = gsap.timeline({ defaults: { ease: "power2.out" } })
      }

      // Apply animations based on state
      if (animState === "top") {
        tl.current
          .to(
            SpansDivRef.current,
            {
              transition:"all  ease-in-out",
              visibility: "hidden",
              opacity: 0,
              duration: 0.1,
            },
            0,
          )
          .to(
            arrowRef.current,
            {
              width: "1.5rem",
              height: "1.5rem",
              fontSize: "1rem",
              color: "white",
            },
            0,
          )
          .to(
            circleNameDivRef.current,
            {
               visibility :"visible",
              position: "fixed",
              zIndex: 100,
              top: 8,
              left: `calc(${targetLeft}px - 3.9rem)`,
              opacity: 1,
              ease: "power2.out",
            },
            0,
          )
          .to(
            bgArrowRef.current,
            {
              background: "rgb(255 204 0)",
            },
            0,
          )
          .to(
            arrowRef.current,
            {
              width: "1.6rem",
              height: "1.6rem",
              fontSize: "1.5rem",
              color: "#fff",
            },
            0.1,
          )
      } else if (animState === "middle") {
        if(!isMobile)
        {

        
        tl.current
          .to(
            circleNameDivRef.current,
            {
              opacity: 1,
              position: "fixed",
              zIndex: 100,
              bottom: "unset",
              top: `calc(${targetTop}px + 1rem)`,
              left: `calc(${targetLeft}px - 9rem)`,
              onComplete: () => {
                setfontSpansSize(1.5)
                setRadius(80)
              },
            },
            0,
          )
          .to(
            SpansDivRef.current,
            {
              visibility: "visible",
              opacity: 1,
              alpha: 1,
            },
            0,
          )
          .to(
            bgArrowRef.current,
            {
              background: "linear-gradient(45deg, #fff, #fff)",
            },
            0,
          )
          .to(
            arrowRef.current,
            {
              width: "3rem",
              height: "3rem",
              fontSize: "10rem",
              color: "#fee685",
            },
            0.1,
          )
          .duration(0.3)
        }
          else {
            tl.current
            .to(
              circleNameDivRef.current,
              {
                visibility :"hidden",
                opacity: 0,
                // opacity: 1,
                // position: "fixed",
                // zIndex: 100,
                // bottom: "unset",
                // top: `calc(${targetTop}px + 1rem)`,
                // left: `calc(${targetLeft}px - 9rem)`,
                // onComplete: () => {
                //   setfontSpansSize(1.5)
                //   setRadius(80)
                // },
              },
              0,
            )
            
          }
      } else if (animState === "bottom") {
        tl.current
          .to(

            circleNameDivRef.current,
            {
              visibility:"visible",
              opacity: 1,
              position: "fixed",
              zIndex: 100,
              bottom: "1.5rem",
              left: "unset",
              right: "1.5rem",
              top: "auto",
              onComplete: () => {
                setRadius(50)
                setfontSpansSize(1)
              },
            },
            0,
          )
          .to(
            arrowRef.current,
            {
              borderRadius:"999px",
              background: "rgb(255 204 0)",
              visibility:"visible",
              width: "2.5rem",
              height: "2.5rem",
              fontSize: "1rem",
              color: "#fee685",
            },
            0,
          )
          .to(
            SpansDivRef.current,
            {
              visibility: "visible",
              opacity: 1,
              alpha: 1,
            },
            0,
          )
          .to(bgArrowRef.current, {

            // background: "linear-gradient(45deg, #a600ff, #00c3ff)",
          })
          .duration(0.3)
      }
    },
    {
      dependencies: [
        animState,
        headerRef.current?.getBoundingClientRect().left,
        headerRef.current?.getBoundingClientRect().height,
        headerRef.current?.getBoundingClientRect().width,
        headerRef.current?.getBoundingClientRect().top,
        isFirstRender,
      ],
    },
  )

  return (
    <div
      style={{
        position: "fixed",
        zIndex: 100,
        opacity: 0, // Start with opacity 0, will be animated by GSAP
      }}
      ref={circleNameDivRef}
      className="font-sans w-[5rem] h-[5rem] rounded flex items-center justify-center"
    >
      <div
        className="text-primary flex items-center justify-center relative w-[500px] h-[500px]"
        style={{ position: "relative" }}
      >
        <div
          ref={SpansDivRef}
          style={{
            transform: `rotate(${rotation}deg)`,
          }}
          className="absolute z-30 inset-0 flex items-center justify-center"
        >
          {renderSpans()}
        </div>

        <div
          className={cn(
            "w-[200px] z-20 transition-all duration-150 rounded-full h-[200px] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2",
            animState === "middle" ? "bg-primary" : "bg-transparent",
          )}
        />

        <div
          ref={bgArrowRef}
          className="text-center z-30 flex justify-center items-center text-primary text-3xl shadow-lg rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
        >
          <span className="">
            <ArrowDownRightIcon ref={arrowRef} className="rotate-[-83deg] text-amber-200" />
          </span>
        </div>
      </div>
    </div>
  )
}

export default CircularSpin
