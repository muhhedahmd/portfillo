import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/all";
import { useEffect, useRef } from "react";

export default function InstantHorizontalScroll() {
    const containerRef = useRef<HTMLDivElement>(null);
    const contentRef = useRef<HTMLDivElement>(null);

    useGSAP(() => {
        if (!containerRef.current || !contentRef.current) return;

        gsap.registerPlugin(ScrollTrigger);

        const container = containerRef.current;
        const content = contentRef.current;
        const maxScroll = content.scrollWidth - container.clientWidth;

        // INSTANT jump to right when scrolled down
        ScrollTrigger.create({
            trigger: container,
            start: "+=900",
            end: "bottom bottom",
            onUpdate: (self) => {
                console.log(self.progress)
                gsap.to(content, {
                    scrollLeft:
                        (self.progress * maxScroll)
                    , yoyo: true,
                    duration: 0.5,
                    transitionDelay: .1,
                    scrub: true

                });
            },

        });

    }, { scope: containerRef });
    useEffect(() => {
        
        if (containerRef.current && contentRef.current) {
            containerRef.current.style.height = contentRef.current.scrollWidth +"px" 
            console.log(
                "contentRef.current.style.width",  
            )
        }
    }, [])
    
    return (
        <div
        style={{
            height : contentRef.current  && containerRef.current?  `${contentRef.current.scrollWidth - containerRef.current.clientWidth   -1500  }px` : "530vh"
        }}
        ref={containerRef} className="  bg-neutral-800 scrollbar-hide  w-full">
            <div className="sticky ] top-0 h-screen w-full overflow-hidden">

                <div ref={contentRef} className="h-full w-full flex overflow-x-hidden">
                    <div className="flex h-full items-center gap-4 px-4">

                        <h1 className="  text-white text-[24vw]  min-w-max">
                            My Last Work Projects
                        </h1>
                      
                    </div>
                </div>

            </div>
        </div>
    );
}
