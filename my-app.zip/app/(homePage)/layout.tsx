import type { Metadata } from "next";
// import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import localFont from 'next/font/local'

// const geistSans = Geist({
//   variable: "--font-geist-sans",
//   subsets: ["latin"],
// });


const goodtimeFont =  localFont({
  src: '/GOODTIME.woff',
  display: 'swap',
  fallback: ['Helvetica', 'Arial', 'sans-serif'],
  
})


export const metadata: Metadata = {
  title: "Mohamed Ahmed - Frontend Next.js Developer",
  description:
    "Portfolio of Mohamed Ahmed Elsaid, a passionate Frontend Developer specializing in Next.js, React, and modern web technologies.",
  keywords: "Frontend Developer, Next.js, React, TypeScript, Web Development, Portfolio",
  authors: [{ name: "Mohamed Ahmed Elsaid" }],
  openGraph: {
    title: "Mohamed Ahmed - Frontend Next.js Developer",
    description: "Portfolio showcasing innovative web applications and cutting-edge frontend development.",
    type: "website",
  },
}
// const geistMono = Geist_Mono({
//   variable: "--font-geist-mono",
//   subsets: ["latin"],
// });


export default function RootLayout({
  
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html 
    
    
    lang="en">
      <body
        className={`
          overflow-x-hidden
          ${goodtimeFont.className}
          antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
