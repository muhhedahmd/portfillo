
import React, { RefObject } from 'react'
// import dynamic from 'next/dynamic'
import CirclureSpin from "../../_components/landing/CirclureSpin";


// const Landing3d = dynamic(() => import('./3d/landing3d'), { ssr: false })
// const Waves = dynamic(() => import('./3d/Waves'), { ssr: false })
// import Landing3d from './landing3d'

const LandingScene = ({
  headerRef,
  lineRefs,
  animState,
  scrollProgress
}: {
  scrollProgress: number,
  headerRef: RefObject<HTMLDivElement | null>
  lineRefs: RefObject<HTMLElement[]>
  animState: 'top' | 'middle' | 'bottom' | 'top2'
}) => {


  return (
    <div className='w-full bg-black py-[8vh]'>


      <div className=" bg-black flex justify-start items-center  min-h-max  md:py-[10vh] md:pl-[26vh] pl-[2rem]  ">

        <div className="relative z-100 space-y-1  max-w-[99%] ">


          <p ref={el => { if (el) lineRefs.current[0] = el; }}
            style={{
                      
              textShadow:"2px 3px 0px  #fefeef ",
              // boxShadow: "2px 3px 4px #fff",
              display: "inline-block", // Ensures shadow wraps the character
            }}
          
          className="text-4xl font-bold text-amber-400">Full Stack Developer</p>
          <p ref={el => { if (el) lineRefs.current[1] = el; }} className="text-xl">Hey there! I&apos;m <span className="font-semibold">Mohamed Ahmed</span>.</p>
          <p
            ref={(el) => {
              if (el) lineRefs.current[2] = el;
            }}
            className="text-lg max-w-xl"
          >
            {"A passionate full stack developer with 2 years of hands-on experience building dynamic,"}
          </p>

          <p className='max-w-[99%] ' ref={el => { if (el) lineRefs.current[3] = el; }}>

            responsive, and user-focused web applications. I love crafting clean code, intuitive interfaces,
          </p>
          <p ref={el => { if (el) lineRefs.current[4] = el; }}>

            and solving real-world problems through technology.
          </p>
        </div>
        <CirclureSpin
          headerRef={headerRef}
          scrollProgress={scrollProgress}
          animState={animState} />

      </div>


    </div>
  )
}

export default LandingScene