"use client"
import { useEffect, useState } from "react"

const useScrollSpeed = () => {
  const [scrollSpeed, setScrollSpeed] = useState(0)
  const [lastScrollTop, setLastScrollTop] = useState(0)
  const [lastScrollTime, setLastScrollTime] = useState(Date.now())

  useEffect(() => {
    const handleScroll = () => {
      const currentTime = Date.now()
      const currentScrollTop = window.scrollY
      const timeDelta = currentTime - lastScrollTime

      if (timeDelta > 0) {
        // Calculate pixels per millisecond
        const scrollDelta = currentScrollTop - lastScrollTop
        const speed = (scrollDelta / timeDelta) * 10 // Multiply by 10 to make it more noticeable

        setScrollSpeed(speed)
        setLastScrollTop(currentScrollTop)
        setLastScrollTime(currentTime)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [lastScrollTop, lastScrollTime])

  return scrollSpeed
}

export default useScrollSpeed
