
import { cn } from '@/lib/utils'
import React, { RefObject, useLayoutEffect, useRef } from 'react'
import { Home } from 'lucide-react'
import gsap, { TimelineLite } from 'gsap'
import { useGSAP } from '@gsap/react'

const Header = ({
  // lineRefs,
  // isScrolled,
  // ScrollProgress,
  isMobile, 
  headerRef: HeaderRef,
  animState
}: {
  isMobile :boolean,
  headerRef: RefObject<HTMLDivElement | null>
  lineRefs: RefObject<HTMLElement[]>
  animState: 'top' | 'middle' | 'bottom' | 'top2'
  ScrollProgress: number,
  isScrolled: boolean
}) => {

  console.log({isMobile})

  const tl = useRef<TimelineLite | null>(gsap.timeline())
  const innerHeaderRef = useRef<HTMLDivElement | null>(null)
  const boxInner = useRef<HTMLDivElement | null>(null)

  // Animation control based on state
  useGSAP(() => {
    if (!HeaderRef.current) return;

    tl.current?.kill();
    tl.current = gsap.timeline({ overwrite: true });
    console.log(animState)
    switch (animState) {
      case 'top2':
        tl.current
          .to(boxInner.current, { opacity: 1, duration: 0.2 })
          .to(HeaderRef.current, {
            width: "72vw",
            height: "2rem",
            left: "1%",
            top: "2rem",
            duration: 0.3
          }).to(innerHeaderRef.current, {
            width: "100%",
            height: "100%"
          }, 0)
      case 'top':
        tl.current
          .to(boxInner.current, { opacity: 1, duration: 0.2 })
          .to(HeaderRef.current, {
            width: !isMobile ? "75vw" : "85vw",
            height: "2rem",
            left: "50%",
            top: "2rem",
            duration: 0.3
          }).to(innerHeaderRef.current, {
            width: "100%",
            height: "100%"
          }, 0)
        break;

      case 'middle':
        tl.current
          .to(boxInner.current, { opacity: 0, duration: 0.2 })
          .to(HeaderRef.current, {

            borderRadius: "1rem"
          })
          .to(HeaderRef.current, {
            width: !isMobile ? "81vw" : "90vw" ,
            height: "15rem",
            left: "50%",
            top: "1rem",
            duration: 0.3,
          }, "<").to(innerHeaderRef.current, {
            height: "100%",
            width: "100%",
            borderRadius: "1rem"
          }, 0)
        break;

      case 'bottom':
        // tl.current
        // .to(boxInner.current, { 
        //   opacity: 0, 
        //   visibility: "hidden",
        //   duration: 0.1 
        // })
        // .to(HeaderRef.current, {
        //   width: "2rem",
        //   height: "2rem",
        //   left: "6rem",
        //   top: "2rem",
        //   ease: "none",
        //   duration: 0.1,
        //   transitionDelay:".2s"
        // }, 0)
        // .to(HeaderRef.current, {
        //   height: "40rem",
        //   top: "17%",
        //   duration: 0.1
        // }, ">0.5") // Start after 0.1s delay
        // .to(innerHeaderRef.current, { 
        //   height: "100%",
        //   duration: 0.1 
        // }, "<") // Start at same time as previous
        // .to(boxInner.current, {
        //   opacity: 1,
        //   visibility: "visible",
        //   flexDirection: "column",
        //   duration: 0.1
        // }, "<");


        tl.current
          .to(boxInner.current, {
            opacity: 0,
            visibility: "hidden",
            duration: 0.1
          })
          .to(HeaderRef.current, {
            // width: "40vw",
            height: "2rem",
            left: "50%",
            top: "2rem",
              duration: 0.3
          }, 0)
          .to(innerHeaderRef.current, {
            height: "100%",
            duration: 0.1
          }, "<") // Start at same time as previous
          .to(boxInner.current, {
            opacity: 1,
            visibility: "visible",
            flexDirection: "column",
            duration: 0.1
          }, "<");


        break;
    }
  }, [animState , isMobile]); // Only re-run when state changes


  return (
    <>
      <header
        ref={HeaderRef}
        style={{
          background: "#000"
        }}
        className={cn(
          // isScrolled ? "w-[40vw]" : "w-[75vw]",
          ` fixed
                     
          md:w-[90vw] 
          w-[81vw]
            top-[2rem] left-1/2
             -translate-x-1/2
              font-semibold 
              text-[14px] 
               rounded-full shadow-md
                transition-all duration-300 
              z-20
              glow-border
            
            `
        )}
      >


        <div ref={innerHeaderRef} className="relative z-10 px-2 rounded-full w-full h-[2rem]  bg-accent   flex items-center justify-between  text-xl font-bold">
          <div
            ref={boxInner}
            className='flex gap-2'>

            <Home
              className='text-[14px] w-5 h-5'
            />
            {/* <ThemeToggle /> */}
          </div>
        </div>
      </header>
      {/* <div className='w-32 h-32 bg-red-400  relative z-1 '/> */}
    </>
  )
}
export default Header