"use client"
import gsap from "gsap";
import Header from "../_components/landing/Header/Header";
import { useEffect, useRef, useState } from "react";
import ScrollTrigger from 'gsap/ScrollTrigger'
import { useGSAP } from "@gsap/react";
import { LenisRef } from "lenis/react";
import SmoothScrolling from "../_components/lenisScroll/lenis";
import dynamic from "next/dynamic";
const LandingScene = dynamic(() => import("../_components/landing/LandingScene"), { ssr: false });
import { throttle } from 'lodash';
import ParadoxScrollSection from "../_components/paradoxSection";
import InfintyScroll from "../_components/InfintyScroll";
import Footer from "../_components/footer";

gsap.registerPlugin(ScrollTrigger)

export default function Home() {
  const landingPageRef = useRef<HTMLDivElement>(null)
  const [isScrolled,] = useState(false);
  const [ScrollProgress, setScrollProgress] = useState<number>(0);

  const [isMobile, setIsMobile] = useState(false);

  const lineRefs = useRef<HTMLElement[]>([]);

  const lenisRef = useRef<LenisRef>(null)

  useEffect(() => {
    function update(time: number) {
      lenisRef.current?.lenis?.raf(time)
    }
    gsap.ticker.add(update)
    return () => gsap.ticker.remove(update)
  }, [])

  // Check for mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  type AnimationState = 'top' | 'middle' | 'bottom';
  const [animState, setAnimState] = useState<AnimationState>('top');
  const headerRef = useRef<HTMLDivElement | null>(null)

  // Setup infinite horizontal scroll

  // Main scroll trigger
  useGSAP(() => {


    if (!landingPageRef.current) return;


    let lastState: AnimationState = 'top';

    ScrollTrigger.create({
      trigger: landingPageRef.current,
      start: "top top",
      end: "+=500",
      onUpdate: throttle((self: ScrollTrigger) => {
        const maxVelocity = 2000;

        const velocity = Math.abs(self.getVelocity());
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const normalizedVelocity = Math.min(velocity / maxVelocity, 1);
        // console.log(normalizedVelocity, self)
        const progress = self.progress;
        let newState: AnimationState;


        setScrollProgress(progress)
        if (progress < 0.05) {
          newState = 'top';
        } else if (progress >= 0.05 && progress <= 0.7) {
          newState = 'middle';
        } else {
          newState = 'bottom';
        }

        if (newState !== lastState) {
          setAnimState(newState);
          lastState = newState;
        }
      }, 50)
    });
  }, [landingPageRef.current]);

  const lenuisRef = useRef<LenisRef>(null)

  return (
    <>
    <SmoothScrolling ref={lenuisRef} >

      <div ref={landingPageRef} className="overflow-x-hidden relative">
        <Header
          isMobile={isMobile}
          headerRef={headerRef}
          animState={animState}
          lineRefs={lineRefs}
          isScrolled={isScrolled}
          ScrollProgress={ScrollProgress}
        />

        <LandingScene
          isMobile={isMobile}
          headerRef={headerRef}
          scrollProgress={ScrollProgress}
          animState={animState}
          lineRefs={lineRefs}
        />

        {/* Horizontal Scroller Section */}

        <InfintyScroll
          isMobile={isMobile}
        />




      </div>
      {<ParadoxScrollSection
      // lenuisRef={lenuisRef}
      // scrollProgress={ScrollProgress}
      />}
      {/* <footer className=" pt-24 h-screen bg-amber-100 flex items-end justify-end">
          <div
            style={{
              boxShadow: "#00010022 -1px -4px 10px 4px"
            }}
            className="bg-amber-800/75 rounded-[6rem] rounded-b-none h-[40vh] w-[98vw]"
          />
        </footer> */}
    </SmoothScrolling>
        <div 
        className="absolute bottom-0 w-full"
        >

          <Footer/>
        </div>
   
    </>

  );
}

